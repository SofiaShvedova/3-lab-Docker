const express = require('express');
const { Client } = require('@elastic/elasticsearch');
require('dotenv').config();

const app = express();
app.use(express.json());

const client = new Client({ node: process.env.ELASTICSEARCH_URL });

// Создание индекса и добавление тестовых данных
const createIndexAndSeedData = async () => {
    const exists = await client.indices.exists({ index: 'defects' });
    if (!exists.body) {
        await client.indices.create({ index: 'defects' });
        // Добавляем тестовые данные
        await client.index({ index: 'defects', body: { category: 'UI', description: 'Button is broken', severity: 'critical', createdAt: new Date() } });
        await client.index({ index: 'defects', body: { category: 'API', description: 'Endpoint returns 500', severity: 'major', createdAt: new Date() } });
        await client.index({ index: 'defects', body: { category: 'UI', description: 'Typo in text', severity: 'minor', createdAt: new Date() } });
        await client.indices.refresh({ index: 'defects' }); // Обязательно обновить индекс, чтобы изменения были видны
    }
};


// Добавление дефекта (остается без изменений)
app.post('/api/defects', async (req, res) => {
    const { category, description, severity } = req.body;
    const response = await client.index({
        index: 'defects',
        body: { category, description, severity, createdAt: new Date() }
    });
    res.status(201).send(response.body);
});

// Получение всех дефектов (остается без изменений)
app.get('/api/defects', async (req, res) => {
    const { body } = await client.search({
        index: 'defects',
        body: { query: { match_all: {} } }
    });
    res.send(body.hits.hits.map(hit => hit._source));
});

// Отчет по категориям (остается без изменений)
app.get('/api/report', async (req, res) => {
    const response = await client.search({
        index: 'defects',
        body: {
            aggs: {
                categories: {
                    terms: { field: 'category' },
                    aggs: {
                        defectCount: { value_count: { field: 'severity' } }
                    }
                }
            }
        }
    });
    res.send(response.body.aggregations.categories.buckets);
});

// Запуск сервера
const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
    await createIndexAndSeedData();
    console.log(`Server running on http://localhost:${PORT}`); // Исправлено: добавлена обратная кавычка
})