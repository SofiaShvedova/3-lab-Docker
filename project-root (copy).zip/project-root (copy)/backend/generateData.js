const client = require('./client');
const categories = ['Electronics', 'Furniture', 'Clothing'];

const generateDefects = async () => {
    for (let i = 0; i < 100; i++) {
        const defect = {
            category: categories[Math.floor(Math.random() * categories.length)],
            description: `Defect description ${i + 1}`,
            severity: Math.random() < 0.5 ? 'High' : 'Low',
        };
        await client.index({
            index: 'defects',
            body: { ...defect, createdAt: new Date() },
        });
    }
    console.log('Тестовые данные сгенерированы.');
    client.close();
};

generateDefects();